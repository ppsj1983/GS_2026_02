import os
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

import geopandas as gpd
import pandas as pd
import requests
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent.parent

class ConsultaIn(BaseModel):
    endereco: str = Field(min_length=5, max_length=250)
    data: str
    periodo: str

class MotorRisco:
    def __init__(self):
        self.mapa_areas = None
        self.probabilidades = None
        self.mapa_final = None
        self.carregado = False
        self.erro = None

    def _path(self, key):
        value = os.getenv(key, '')
        p = Path(value)
        return p if p.is_absolute() else BASE_DIR / p

    def carregar(self):
        try:
            shp = self._path('VORONOI_SHP')
            csv = self._path('PROBABILIDADES_CSV')
            geojson = self._path('MAPA_FINAL_GEOJSON')
            self.mapa_areas = gpd.read_file(shp)
            if self.mapa_areas.crs is None:
                self.mapa_areas = self.mapa_areas.set_crs(epsg=31983)
            self.probabilidades = pd.read_csv(csv, sep=';', decimal=',', encoding='utf-8-sig')
            self.mapa_final = gpd.read_file(geojson).to_crs(4326)
            self.carregado = True
        except Exception as exc:
            self.erro = str(exc)
            self.carregado = False

    def geocodificar(self, endereco):
        chave = os.getenv('GOOGLE_MAPS_API_KEY')
        if not chave:
            raise HTTPException(500, 'GOOGLE_MAPS_API_KEY não configurada.')
        r = requests.get('https://maps.googleapis.com/maps/api/geocode/json', params={
            'address': endereco, 'key': chave, 'region': 'br', 'language': 'pt-BR'
        }, timeout=15)
        r.raise_for_status()
        body = r.json()
        if body.get('status') != 'OK' or not body.get('results'):
            raise HTTPException(422, f"Endereço não localizado: {body.get('status')}")
        item = body['results'][0]
        loc = item['geometry']['location']
        return loc['lat'], loc['lng'], item['formatted_address']

    def clima(self, lat, lon, data_str, periodo):
        data = datetime.strptime(data_str, '%d/%m/%Y')
        r = requests.get('https://api.open-meteo.com/v1/forecast', params={
            'latitude': lat, 'longitude': lon,
            'hourly': 'temperature_2m,precipitation,precipitation_probability',
            'timezone': 'America/Sao_Paulo',
            'start_date': data.strftime('%Y-%m-%d'), 'end_date': data.strftime('%Y-%m-%d')
        }, timeout=15)
        r.raise_for_status()
        hourly = r.json().get('hourly', {})
        df = pd.DataFrame(hourly).rename(columns={
            'time':'data_hora','temperature_2m':'temp_c','precipitation':'chuva_mm',
            'precipitation_probability':'prob_pct'
        })
        if df.empty:
            raise HTTPException(422, 'Sem previsão meteorológica para a data informada.')
        df['data_hora'] = pd.to_datetime(df['data_hora'])
        df['DATA'] = df['data_hora'].dt.strftime('%d/%m/%Y')
        df['DIA_SEM'] = df['data_hora'].dt.dayofweek.map(dict(enumerate(['seg','ter','qua','qui','sex','sáb','dom'])))
        df['PERIODO'] = pd.cut(df['data_hora'].dt.hour, [-1,5,11,17,23], labels=['MADRUGADA','MANHA','TARDE','NOITE']).astype(str)
        f = df[(df.DATA == data_str) & (df.PERIODO == periodo)]
        if f.empty:
            raise HTTPException(422, 'Data/período sem dados meteorológicos.')
        return {
            'DATA': data_str, 'DIA_SEM': f.DIA_SEM.iloc[0], 'PERIODO': periodo,
            'temp_media_c': round(float(f.temp_c.mean()),2),
            'chuva_total_mm': round(float(f.chuva_mm.sum()),2),
            'prob_media_pct': round(float(f.prob_pct.mean()),2)
        }

    def consultar(self, q):
        if not self.carregado:
            raise HTTPException(503, f'Bases não carregadas: {self.erro}')
        lat, lon, ref = self.geocodificar(q.endereco)
        clima = self.clima(lat, lon, q.data, q.periodo)
        ponto = gpd.GeoDataFrame([{'LATITUDE':lat,'LONGITUDE':lon}], geometry=gpd.points_from_xy([lon],[lat]), crs=4326).to_crs(self.mapa_areas.crs)
        join = gpd.sjoin(ponto, self.mapa_areas[['id_celula','geometry']], how='left', predicate='within')
        if join.empty or pd.isna(join.iloc[0].get('id_celula')):
            raise HTTPException(422, 'Endereço fora das células mapeadas.')
        celula = join.iloc[0]['id_celula']
        base = pd.DataFrame([{
            'ENDERECO_REFERENCIA': ref, 'LATITUDE': lat, 'LONGITUDE': lon,
            'id_celula': celula, **clima
        }])
        out = base.merge(self.probabilidades, on=['id_celula','DIA_SEM','PERIODO'], how='left')
        out = out.where(pd.notnull(out), None)
        return {'endereco_formatado':ref, 'latitude':lat, 'longitude':lon, 'id_celula':celula, 'registros':out.to_dict('records')}

motor = MotorRisco()

@asynccontextmanager
async def lifespan(app: FastAPI):
    motor.carregar()
    yield

app = FastAPI(title='API de Análise de Risco', lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=os.getenv('CORS_ORIGINS','http://localhost:5173').split(','), allow_methods=['*'], allow_headers=['*'])

@app.get('/api/health')
def health():
    return {'carregado': motor.carregado, 'erro': motor.erro}

@app.post('/api/consulta')
def consulta(q: ConsultaIn):
    q.periodo = q.periodo.upper()
    if q.periodo not in {'MADRUGADA','MANHA','TARDE','NOITE'}:
        raise HTTPException(422, 'Período inválido.')
    try: datetime.strptime(q.data, '%d/%m/%Y')
    except ValueError: raise HTTPException(422, 'Data deve usar DD/MM/AAAA.')
    return motor.consultar(q)

@app.get('/api/mapas')
def mapas():
    if not motor.carregado:
        raise HTTPException(503, f'Bases não carregadas: {motor.erro}')
    cols = ['id_celula','ACIDENTE_TRANSITO','ALAGAMENTO_VIAS_PUBLICAS','DEFESA_CIVIL','SEGURANCA_PUBLICA','PROB_EXATA_PCT','geometry']
    return {
        'titulo':'Análise Espacial e Escalas Quantitativas de Risco por Célula',
        'geojson': motor.mapa_final[cols].to_json()
    }
