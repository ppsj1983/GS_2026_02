# Análise de Risco por Endereço

Aplicação com React (Vite) no frontend e FastAPI no backend.

## Arquitetura
- O backend processa e mantém em memória as bases, o Voronoi e `probabilidades_consolidadas` durante a inicialização.
- Somente endereço, data e período mudam a cada consulta.
- O frontend mostra o resultado da consulta e cinco abas de mapas.

## Backend
1. Copie os shapefiles e Excel para `backend/data` e ajuste as variáveis do `.env`.
2. Crie o ambiente e instale:
   ```bash
   cd backend
   python -m venv .venv
   .venv\\Scripts\\activate
   pip install -r requirements.txt
   copy .env.example .env
   uvicorn app.main:app --reload --port 8000
   ```

## Frontend
```bash
cd frontend
npm install
npm run dev
```

Abra `http://localhost:5173`.

## Segurança
A chave Google não deve ficar no React nem no código-fonte. Use `GOOGLE_MAPS_API_KEY` no `.env` do backend. A chave encontrada no script original deve ser revogada/rotacionada no Google Cloud Console.

## Contratos
- `POST /api/consulta`: recebe `endereco`, `data` e `periodo`; devolve o equivalente JSON de `df_resultado_completo`.
- `GET /api/mapas`: devolve GeoJSON de cinco indicadores já processados.
- `GET /api/health`: informa se as bases foram carregadas.
