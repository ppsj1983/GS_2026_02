import React,{useEffect,useMemo,useState}from'react';
import{MapContainer,TileLayer,GeoJSON}from'react-leaflet';
const API=import.meta.env.VITE_API_URL||'http://localhost:8000';
const abas=[
 ['ACIDENTE_TRANSITO','Acidente de Trânsito'],['ALAGAMENTO_VIAS_PUBLICAS','Alagamento em Vias Públicas'],
 ['DEFESA_CIVIL','Defesa Civil'],['SEGURANCA_PUBLICA','Segurança Pública'],['PROB_EXATA_PCT','Probabilidade Combinada de Risco']
];
function cor(v,max){const p=max?Math.max(0,Math.min(1,v/max)):0;return `hsl(${45-45*p} 88% ${92-50*p}%)`}
export default function App(){
 const[f,setF]=useState({endereco:'RUA QUERANDIES 16 PIRITUBA',data:'15/11/2026',periodo:'TARDE'});
 const[res,setRes]=useState(null),[geo,setGeo]=useState(null),[aba,setAba]=useState(0),[loading,setLoading]=useState(false),[erro,setErro]=useState('');
 useEffect(()=>{fetch(`${API}/api/mapas`).then(r=>r.ok?r.json():Promise.reject(r)).then(x=>setGeo(JSON.parse(x.geojson))).catch(()=>setErro('Os mapas ainda não estão disponíveis. Verifique o backend.'))},[]);
 const campo=abas[aba][0];
 const max=useMemo(()=>geo?Math.max(...geo.features.map(x=>Number(x.properties[campo]||0)),0):0,[geo,campo]);
 async function consultar(e){e.preventDefault();setLoading(true);setErro('');try{const r=await fetch(`${API}/api/consulta`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(f)});const x=await r.json();if(!r.ok)throw new Error(x.detail||'Falha na consulta');setRes(x)}catch(e){setErro(e.message)}finally{setLoading(false)}}
 return <main>
  <header><h1>Análise de Risco por Endereço</h1><p>Consulta climática, espacial e quantitativa por célula.</p></header>
  <section className="card"><h2>Nova consulta</h2><form onSubmit={consultar}>
   <label>Endereço<input value={f.endereco} onChange={e=>setF({...f,endereco:e.target.value})} required/></label>
   <label>Data<input value={f.data} onChange={e=>setF({...f,data:e.target.value})} placeholder="DD/MM/AAAA" required/></label>
   <label>Período<select value={f.periodo} onChange={e=>setF({...f,periodo:e.target.value})}><option>MADRUGADA</option><option>MANHA</option><option>TARDE</option><option>NOITE</option></select></label>
   <button disabled={loading}>{loading?'Processando...':'Pesquisar'}</button>
  </form>{erro&&<p className="erro" role="alert">{erro}</p>}</section>
  {res&&<section className="card"><h2>Resultado da consulta</h2><p><b>{res.endereco_formatado}</b> · célula {res.id_celula}</p><div className="tableWrap"><table><thead><tr>{Object.keys(res.registros[0]||{}).map(k=><th key={k}>{k}</th>)}</tr></thead><tbody>{res.registros.map((r,i)=><tr key={i}>{Object.values(r).map((v,j)=><td key={j}>{typeof v==='number'?v.toLocaleString('pt-BR'):String(v??'')}</td>)}</tr>)}</tbody></table></div></section>}
  <section className="card"><h2>Análise Espacial e Escalas Quantitativas de Risco por Célula</h2><div className="tabs" role="tablist">{abas.map((x,i)=><button type="button" className={aba===i?'active':''} onClick={()=>setAba(i)} key={x[0]}>{x[1]}</button>)}</div>
   <div className="map">{geo?<MapContainer center={[-23.55,-46.63]} zoom={10} style={{height:'100%',width:'100%'}}><TileLayer attribution='&copy; OpenStreetMap' url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'/><GeoJSON key={campo} data={geo} style={f=>({color:'#555',weight:.35,fillOpacity:.82,fillColor:cor(Number(f.properties[campo]||0),max)})} onEachFeature={(f,l)=>l.bindTooltip(`${abas[aba][1]}: ${Number(f.properties[campo]||0).toLocaleString('pt-BR',{maximumFractionDigits:2})}<br/>Célula: ${f.properties.id_celula}`)}/></MapContainer>:<p>Carregando mapa...</p>}</div>
  </section>
 </main>
}