import os
import json
import logging
from pathlib import Path
from datetime import datetime
from contextlib import asynccontextmanager

import truststore
import requests
import pandas as pd
import geopandas as gpd

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


# =========================================================
# CONFIGURAÇÃO
# =========================================================

truststore.inject_into_ssl()
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

log = logging.getLogger("analise_risco")


# =========================================================
# MODELO DE ENTRADA
# =========================================================

class ConsultaIn(BaseModel):
    endereco: str = Field(min_length=5, max_length=250)
    data: str
    periodo: str


# =========================================================
# MOTOR DE ANÁLISE
# =========================================================

class MotorRisco:

    def __init__(self):
        self.mapa_areas = None
        self.probabilidades = None
        self.mapa_final = None
        self.carregado = False
        self.erro = None

    def caminho(self, variavel):
        valor = os.getenv(variavel, "").strip()

        if not valor:
            raise ValueError(
                f"Variável {variavel} não configurada no arquivo .env."
            )

        caminho = Path(valor)

        if not caminho.is_absolute():
            caminho = BASE_DIR / caminho

        return caminho.resolve()

    @staticmethod
    def normalizar_id(serie):
        return (
            serie.astype(str)
            .str.strip()
            .str.replace(r"\.0$", "", regex=True)
        )

    def carregar(self):
        try:
            caminho_shp = self.caminho("VORONOI_SHP")
            caminho_csv = self.caminho("PROBABILIDADES_CSV")
            caminho_geojson = self.caminho("MAPA_FINAL_GEOJSON")

            log.info("Carregando células: %s", caminho_shp)
            log.info("Carregando probabilidades: %s", caminho_csv)
            log.info("Carregando mapa final: %s", caminho_geojson)

            self.mapa_areas = gpd.read_file(caminho_shp)

            self.probabilidades = pd.read_csv(
                caminho_csv,
                sep=";",
                decimal=",",
                encoding="utf-8-sig"
            )

            self.mapa_final = gpd.read_file(caminho_geojson)

            # Remove espaços nos nomes das colunas
            self.mapa_areas.columns = (
                self.mapa_areas.columns.astype(str).str.strip()
            )

            self.probabilidades.columns = (
                self.probabilidades.columns.astype(str).str.strip()
            )

            self.mapa_final.columns = (
                self.mapa_final.columns.astype(str).str.strip()
            )

            # Validação das colunas obrigatórias
            colunas_areas = {"id_celula", "geometry"}
            colunas_prob = {
                "id_celula",
                "DIA_SEM",
                "PERIODO",
                "MACRO_GRUPO",
                "PROB_PERIODO_DIA",
                "PROB_GERAL_DIA"
            }

            faltantes_areas = (
                colunas_areas - set(self.mapa_areas.columns)
            )

            faltantes_prob = (
                colunas_prob - set(self.probabilidades.columns)
            )

            if faltantes_areas:
                raise ValueError(
                    "Colunas ausentes no shapefile: "
                    + ", ".join(sorted(faltantes_areas))
                )

            if faltantes_prob:
                raise ValueError(
                    "Colunas ausentes no CSV: "
                    + ", ".join(sorted(faltantes_prob))
                )

            # Sistema de coordenadas
            if self.mapa_areas.crs is None:
                self.mapa_areas = self.mapa_areas.set_crs(
                    "EPSG:31983",
                    allow_override=True
                )

            if self.mapa_final.crs is None:
                self.mapa_final = self.mapa_final.set_crs(
                    "EPSG:4326",
                    allow_override=True
                )
            else:
                self.mapa_final = self.mapa_final.to_crs("EPSG:4326")

            # Padronização das chaves do merge
            self.mapa_areas["id_celula"] = self.normalizar_id(
                self.mapa_areas["id_celula"]
            )

            self.probabilidades["id_celula"] = self.normalizar_id(
                self.probabilidades["id_celula"]
            )

            self.probabilidades["DIA_SEM"] = (
                self.probabilidades["DIA_SEM"]
                .astype(str)
                .str.strip()
                .str.lower()
            )

            self.probabilidades["PERIODO"] = (
                self.probabilidades["PERIODO"]
                .astype(str)
                .str.strip()
                .str.upper()
            )

            if "id_celula" in self.mapa_final.columns:
                self.mapa_final["id_celula"] = self.normalizar_id(
                    self.mapa_final["id_celula"]
                )

            self.carregado = True
            self.erro = None

            log.info("Bases carregadas com sucesso.")
            log.info("Células: %s", len(self.mapa_areas))
            log.info(
                "Registros de probabilidades: %s",
                len(self.probabilidades)
            )
            log.info("Geometrias do mapa: %s", len(self.mapa_final))

        except Exception as erro:
            self.carregado = False
            self.erro = str(erro)
            log.exception("Erro ao carregar as bases.")

    def geocodificar(self, endereco):
        chave_api = os.getenv("GOOGLE_MAPS_API_KEY", "").strip()

        if not chave_api:
            raise HTTPException(
                status_code=500,
                detail="GOOGLE_MAPS_API_KEY não configurada."
            )

        try:
            resposta = requests.get(
                "https://maps.googleapis.com/maps/api/geocode/json",
                params={
                    "address": endereco,
                    "key": chave_api,
                    "region": "br",
                    "language": "pt-BR"
                },
                timeout=20
            )

            resposta.raise_for_status()
            dados = resposta.json()

        except requests.exceptions.SSLError as erro:
            raise HTTPException(
                status_code=502,
                detail=f"Erro SSL na API Google: {erro}"
            )

        except requests.RequestException as erro:
            raise HTTPException(
                status_code=502,
                detail=f"Erro de conexão com a API Google: {erro}"
            )

        if dados.get("status") != "OK" or not dados.get("results"):
            mensagem = dados.get(
                "error_message",
                dados.get("status", "erro desconhecido")
            )

            raise HTTPException(
                status_code=422,
                detail=f"Endereço não localizado: {mensagem}"
            )

        resultado = dados["results"][0]
        localizacao = resultado["geometry"]["location"]

        latitude = float(localizacao["lat"])
        longitude = float(localizacao["lng"])
        endereco_formatado = resultado["formatted_address"]

        return latitude, longitude, endereco_formatado

    def consultar_clima(self, latitude, longitude):
        try:
            resposta = requests.get(
                "https://api.open-meteo.com/v1/forecast",
                params={
                    "latitude": latitude,
                    "longitude": longitude,
                    "hourly": (
                        "temperature_2m,"
                        "precipitation,"
                        "precipitation_probability"
                    ),
                    "timezone": "America/Sao_Paulo",
                    "forecast_days": 7
                },
                timeout=20
            )

            resposta.raise_for_status()
            dados = resposta.json()

        except requests.exceptions.SSLError as erro:
            raise HTTPException(
                status_code=502,
                detail=f"Erro SSL na Open-Meteo: {erro}"
            )

        except requests.RequestException as erro:
            raise HTTPException(
                status_code=502,
                detail=f"Erro de conexão com a Open-Meteo: {erro}"
            )

        hourly = dados.get("hourly")

        if not hourly:
            raise HTTPException(
                status_code=422,
                detail="A Open-Meteo não retornou dados horários."
            )

        return hourly

    def preparar_clima(
        self,
        hourly,
        data_str,
        periodo,
        endereco_ref,
        latitude,
        longitude
    ):
        df = pd.DataFrame(hourly).rename(
            columns={
                "time": "data_hora",
                "temperature_2m": "temp_c",
                "precipitation": "chuva_mm",
                "precipitation_probability": "prob_pct"
            }
        )

        if df.empty:
            raise HTTPException(
                status_code=422,
                detail="Sem dados meteorológicos."
            )

        df["data_hora"] = pd.to_datetime(
            df["data_hora"],
            errors="coerce"
        )

        df = df.dropna(subset=["data_hora"])

        df["DATA"] = (
            df["data_hora"]
            .dt.strftime("%d/%m/%Y")
        )

        df["DIA_SEM"] = (
            df["data_hora"]
            .dt.dayofweek
            .map(
                dict(
                    enumerate(
                        [
                            "seg",
                            "ter",
                            "qua",
                            "qui",
                            "sex",
                            "sáb",
                            "dom"
                        ]
                    )
                )
            )
        )

        df["PERIODO"] = pd.cut(
            df["data_hora"].dt.hour,
            [-1, 5, 11, 17, 23],
            labels=[
                "MADRUGADA",
                "MANHA",
                "TARDE",
                "NOITE"
            ]
        ).astype(str)

        filtro = df.query(
            "DATA == @data_str and PERIODO == @periodo"
        ).copy()

        if filtro.empty:
            datas_disponiveis = sorted(
                df["DATA"].dropna().unique().tolist()
            )

            raise HTTPException(
                status_code=422,
                detail={
                    "mensagem": (
                        "Não existem dados meteorológicos para "
                        f"{data_str}, período {periodo}."
                    ),
                    "datas_disponiveis": datas_disponiveis
                }
            )

        df_resumo = (
            filtro
            .assign(
                ENDERECO_REFERENCIA=endereco_ref,
                LATITUDE=latitude,
                LONGITUDE=longitude
            )
            .groupby(
                [
                    "ENDERECO_REFERENCIA",
                    "LATITUDE",
                    "LONGITUDE",
                    "DATA",
                    "DIA_SEM",
                    "PERIODO"
                ],
                as_index=False
            )
            .agg(
                temp_media_c=("temp_c", "mean"),
                chuva_total_mm=("chuva_mm", "sum"),
                prob_media_pct=("prob_pct", "mean")
            )
            .round(2)
        )

        return df_resumo

    def cruzamento_espacial(self, df_resumo):
        gdf_ponto = gpd.GeoDataFrame(
            df_resumo,
            geometry=gpd.points_from_xy(
                df_resumo["LONGITUDE"],
                df_resumo["LATITUDE"]
            ),
            crs="EPSG:4326"
        )

        if gdf_ponto.crs != self.mapa_areas.crs:
            gdf_ponto = gdf_ponto.to_crs(
                self.mapa_areas.crs
            )

        resultado = (
            gpd.sjoin(
                gdf_ponto,
                self.mapa_areas[["id_celula", "geometry"]],
                how="left",
                predicate="within"
            )
            .drop(
                columns=["geometry", "index_right"],
                errors="ignore"
            )
        )

        if (
            resultado.empty
            or resultado["id_celula"].isna().all()
        ):
            raise HTTPException(
                status_code=422,
                detail="Endereço fora das células mapeadas."
            )

        resultado["id_celula"] = self.normalizar_id(
            resultado["id_celula"]
        )

        resultado["DIA_SEM"] = (
            resultado["DIA_SEM"]
            .astype(str)
            .str.strip()
            .str.lower()
        )

        resultado["PERIODO"] = (
            resultado["PERIODO"]
            .astype(str)
            .str.strip()
            .str.upper()
        )

        return resultado

    def cruzar_probabilidades(self, resultado_espacial):
        chave = resultado_espacial[
            ["id_celula", "DIA_SEM", "PERIODO"]
        ].iloc[0].to_dict()

        log.info("Chave pesquisada: %s", chave)

        registros_celula = self.probabilidades[
            self.probabilidades["id_celula"]
            == chave["id_celula"]
        ]

        log.info(
            "Registros disponíveis para a célula: %s",
            len(registros_celula)
        )

        resultado = resultado_espacial.merge(
            self.probabilidades,
            on=["id_celula", "DIA_SEM", "PERIODO"],
            how="left",
            indicator=True
        )

        encontrou = resultado["_merge"].eq("both").any()

        if not encontrou:
            dias = sorted(
                registros_celula["DIA_SEM"]
                .dropna()
                .unique()
                .tolist()
            )

            periodos = sorted(
                registros_celula["PERIODO"]
                .dropna()
                .unique()
                .tolist()
            )

            raise HTTPException(
                status_code=422,
                detail={
                    "mensagem": (
                        "A célula foi localizada, mas não existe "
                        "probabilidade para a combinação pesquisada."
                    ),
                    "chave_pesquisada": chave,
                    "dias_disponiveis": dias,
                    "periodos_disponiveis": periodos
                }
            )

        return resultado.drop(columns=["_merge"])

    def consultar(self, consulta):
        if not self.carregado:
            raise HTTPException(
                status_code=503,
                detail=f"Bases não carregadas: {self.erro}"
            )

        latitude, longitude, endereco_ref = self.geocodificar(
            consulta.endereco
        )

        hourly = self.consultar_clima(
            latitude,
            longitude
        )

        df_resumo = self.preparar_clima(
            hourly=hourly,
            data_str=consulta.data,
            periodo=consulta.periodo,
            endereco_ref=endereco_ref,
            latitude=latitude,
            longitude=longitude
        )

        resultado_espacial = self.cruzamento_espacial(
            df_resumo
        )

        df_resultado_completo = self.cruzar_probabilidades(
            resultado_espacial
        )

        registros = json.loads(
            df_resultado_completo.to_json(
                orient="records",
                force_ascii=False,
                date_format="iso"
            )
        )

        return {
            "endereco_formatado": endereco_ref,
            "latitude": latitude,
            "longitude": longitude,
            "id_celula": str(
                resultado_espacial["id_celula"].iloc[0]
            ),
            "total_registros": len(registros),
            "registros": registros
        }


# =========================================================
# INICIALIZAÇÃO
# =========================================================

motor = MotorRisco()


@asynccontextmanager
async def lifespan(app: FastAPI):
    motor.carregar()
    yield


app = FastAPI(
    title="API de Análise de Risco",
    version="1.0.0",
    lifespan=lifespan
)


# =========================================================
# CORS
# =========================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173"
    ],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"]
)


# =========================================================
# ROTAS
# =========================================================

@app.get("/")
def inicio():
    return {
        "status": "API funcionando",
        "health": "/api/health",
        "documentacao": "/docs",
        "mapas": "/api/mapas"
    }


@app.get("/api/health")
def health():
    return {
        "carregado": motor.carregado,
        "erro": motor.erro,
        "total_celulas": (
            len(motor.mapa_areas)
            if motor.mapa_areas is not None
            else 0
        ),
        "total_probabilidades": (
            len(motor.probabilidades)
            if motor.probabilidades is not None
            else 0
        ),
        "total_geometrias": (
            len(motor.mapa_final)
            if motor.mapa_final is not None
            else 0
        )
    }


@app.post("/api/consulta")
def consulta(dados: ConsultaIn):
    endereco = dados.endereco.strip()
    data = dados.data.strip()
    periodo = dados.periodo.strip().upper()

    try:
        datetime.strptime(data, "%d/%m/%Y")
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail="Data inválida. Use DD/MM/AAAA."
        )

    periodos_validos = {
        "MADRUGADA",
        "MANHA",
        "TARDE",
        "NOITE"
    }

    if periodo not in periodos_validos:
        raise HTTPException(
            status_code=422,
            detail=(
                "Período inválido. Use MADRUGADA, "
                "MANHA, TARDE ou NOITE."
            )
        )

    consulta_validada = ConsultaIn(
        endereco=endereco,
        data=data,
        periodo=periodo
    )

    try:
        return motor.consultar(consulta_validada)

    except HTTPException:
        raise

    except Exception as erro:
        log.exception("Erro não tratado durante a consulta.")

        raise HTTPException(
            status_code=500,
            detail=f"Erro no processamento: {erro}"
        )


@app.get("/api/mapas")
def mapas():
    if not motor.carregado:
        raise HTTPException(
            status_code=503,
            detail=f"Bases não carregadas: {motor.erro}"
        )

    colunas = [
        "id_celula",
        "ACIDENTE_TRANSITO",
        "ALAGAMENTO_VIAS_PUBLICAS",
        "DEFESA_CIVIL",
        "SEGURANCA_PUBLICA",
        "PROB_EXATA_PCT",
        "geometry"
    ]

    faltantes = [
        coluna
        for coluna in colunas
        if coluna not in motor.mapa_final.columns
    ]

    if faltantes:
        raise HTTPException(
            status_code=500,
            detail={
                "mensagem": (
                    "O mapa final não possui todas "
                    "as colunas necessárias."
                ),
                "colunas_ausentes": faltantes,
                "colunas_disponiveis": (
                    motor.mapa_final.columns.tolist()
                )
            }
        )

    return {
        "titulo": (
            "Análise Espacial e Escalas "
            "Quantitativas de Risco por Célula"
        ),
        "geojson": motor.mapa_final[colunas].to_json(
            drop_id=True
        )
    }